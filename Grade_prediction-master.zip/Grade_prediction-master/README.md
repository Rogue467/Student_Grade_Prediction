# Grade_prediction
An ML-based model deployed on the web using Flask which predicts the grade of a student at IIT Guwahati. A model trained using a small dataset of 380 students via offline survey consisting of 40+ personal questions.  

## A Detailed Report:
https://drive.google.com/file/d/1B1c6bxdfdfDNO4M-1CDG2sfG-MwWgHLl/view?usp=sharing
